package ʾ��;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Main2014302580075 {

	public static void main(String[] args) throws IOException {
		// TODO �Զ����ɵķ������
		/*
		 * ���ԣ�http://staff.whu.edu.cn/show.jsp?lang=cn&n=Lv%20Hui
		 */
		String url="http://staff.whu.edu.cn/show.jsp?lang=cn&n=Lv%20Hui";//��ʦ��ҳ
		String mail="\\w{3,}@\\w+(\\.\\w{2,3}){1,3}";//�����ʼ�����
		String telephoneNumber="\\d{3}-\\d+";//����������

		ArrayList<String> arrayList1=new ArrayList<>();
		ArrayList<String> mailList=new ArrayList<>();
		ArrayList<String> numList=new ArrayList<>();
		Pattern pmail=Pattern.compile(mail);
		Pattern pphonenum=Pattern.compile(telephoneNumber);
		Document document=Jsoup.connect(url).get();
		Elements elements=document.getElementsByTag("p");
		Elements name=document.getElementsByTag("h3");
		//���������ĵ����д洢
		for (Element element : name) {

			arrayList1.add(element.text());
		}
		for (Element element : elements) {

			arrayList1.add(element.text());
		}
		for (Element element : elements) {
			
			Matcher matcher=pmail.matcher(element.text());
			while (matcher.find()) {

				mailList.add(matcher.group());
				
			}
			Matcher matcher2=pphonenum.matcher(element.text());
			while (matcher2.find()) {

				numList.add(matcher2.group());
			}
		}
		//���洢���ĵ�����д��
		BufferedWriter bufferedWriter=new BufferedWriter(new FileWriter(new File("mine.txt")));
		for(String string:arrayList1){
			bufferedWriter.write(string+"\n");
		}
		bufferedWriter.write("��ȡ������ͺ���:\n"+"����:");
		for(String string:mailList){
			bufferedWriter.write(string+"   ");
		}
		bufferedWriter.write("\n����:");
		for(String string:numList){

			bufferedWriter.write(string+"  ");
		}
		
		bufferedWriter.close();
		
	}

	
}
